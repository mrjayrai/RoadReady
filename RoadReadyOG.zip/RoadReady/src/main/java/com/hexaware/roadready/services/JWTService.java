//package com.hexaware.roadready.services;
///*
// * Author : Pritesh Rai 
// * Description : Service Implementation for jwtService
// * Date: 25-11-2024
// */
//import java.security.Key;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.function.Function;
//
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.stereotype.Service;
//
//import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.Jwts;
//import io.jsonwebtoken.SignatureAlgorithm;
//import io.jsonwebtoken.io.Decoders;
//import io.jsonwebtoken.security.Keys;
//
//@Service
//public class JWTService {
//	
//	public static final String SECRET = "5367566B59703373367639792F423F4528482B4D6251655468576D5A71347437";
//	
//	public String createToken(Map<String, Object> claims, String username,int roleId) {
//
//		return Jwts.builder().setClaims(claims).setSubject(username,roleId).setIssuedAt(new Date(System.currentTimeMillis()))
//				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 10))
//				.signWith(getSignKey(), SignatureAlgorithm.HS256).compact();
//
//	}
//
//	private Key getSignKey() {
//
//		byte[] keyBytes = Decoders.BASE64.decode(SECRET);
//
//		return Keys.hmacShaKeyFor(keyBytes);
//	}
//	
//	public String generateToken(String username,int roleId) {
//
//		Map<String, Object> claims = new HashMap<>();
//
//		return createToken(claims, username,roleId);
//
//	}
//	
//	private Claims extractAllClaims(String token) {
//
//		return Jwts.parserBuilder().setSigningKey(getSignKey()).build().parseClaimsJws(token).getBody();
//
//	}
//
//	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
//
//		final Claims claims = extractAllClaims(token);
//		
//
//		return claimsResolver.apply(claims);
//
//	}
//
//	 public String extractUsername(String token) {
//	        return extractClaim(token, Claims::getSubject);
//	    }
//
//	    public Date extractExpiration(String token) {
//	        return extractClaim(token, Claims::getExpiration);
//	    }
//	    
//	    
//	    private Boolean isTokenExpired(String token) {
//	        return extractExpiration(token).before(new Date());
//	    }
//
//	    public Boolean validateToken(String token, UserDetails userDetails) {
//	        final String username = extractUsername(token);
//	        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
//	    } 
//	
//}



package com.hexaware.roadready.services;

/*
 * Author : Pritesh Rai 
 * Description : Service Implementation for jwtService
 * Date: 25-11-2024
 */

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.hexaware.roadready.dto.LoginDTO;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JWTService {

    public static final String SECRET = "5367566B59703373367639792F423F4528482B4D6251655468576D5A71347437";

    /**
     * Creates a JWT token with claims, username, and role.
     */
    public String createToken(Map<String, Object> claims, String username, String role) {
        // Add the role to the claims
        claims.put("role", role);

        return Jwts.builder()
                .setClaims(claims)                      // Set additional claims (including the role)
                .setSubject(username)                    // Set the subject to the username
                .setIssuedAt(new Date(System.currentTimeMillis())) // Issue date
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 10)) // Token valid for 10 minutes
                .signWith(getSignKey(), SignatureAlgorithm.HS256) // Sign with the secret key
                .compact();                               // Generate the token
    }


    /**
     * Generates a JWT token with the given username and role.
     */
    public String generateToken(String username, String role) {
        Map<String, Object> claims = new HashMap<>();
        return createToken(claims, username, role);
    }

    /**
     * Gets the signing key from the SECRET.
     */
    private Key getSignKey() {
        byte[] keyBytes = Decoders.BASE64.decode(SECRET);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Extracts all claims from the JWT token.
     */
    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    /**
     * Extracts a specific claim from the token using a function.
     */
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    /**
     * Extracts the username (subject) from the token.
     */
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    /**
     * Extracts the role from the token.
     */
    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class));
    }

    /**
     * Extracts the expiration date from the token.
     */
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    /**
     * Checks if the token is expired.
     */
    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    /**
     * Validates the token by checking the username and expiration.
     */
    public Boolean validateToken(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
//        System.out.println(username);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
}

