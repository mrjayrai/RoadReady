package com.hexaware.roadready;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadReadyApplicationTests {

	@Test
	void contextLoads() {
	}

}
